from gerenciador import cadastrar_carta, listar_cartas

cartas = []

while True:
    print("\n=== MENU SUPER TRUNFO ===")
    print("1 - Cadastrar nova carta")
    print("2 - Listar cartas cadastradas")
    print("3 - Sair")

    opcao = input("Escolha uma opção: ")

    if opcao == "1":
        carta = cadastrar_carta()
        cartas.append(carta)
        print("Carta cadastrada com sucesso!\n")

    elif opcao == "2":
        listar_cartas(cartas)

    elif opcao == "3":
        print("Saindo do programa...")
        break

    else:
        print("Opção inválida, tente novamente.")
