from carta import Carta

def cadastrar_carta():
    nome = input("Digite o nome da carta: ")
    forca = int(input("Digite a força: "))
    velocidade = int(input("Digite a velocidade: "))
    inteligencia = int(input("Digite a inteligência: "))
    resistencia = int(input("Digite a resistência: "))

    return Carta(nome, forca, velocidade, inteligencia, resistencia)

def listar_cartas(cartas):
    if not cartas:
        print("Nenhuma carta cadastrada ainda.\n")
    else:
        print("\n=== Cartas Cadastradas ===")
        for i, carta in enumerate(cartas, start=1):
            print(f"\nCarta {i}:")
            print(carta)
