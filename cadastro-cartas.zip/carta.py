class Carta:
    def __init__(self, nome, forca, velocidade, inteligencia, resistencia):
        self.nome = nome
        self.forca = forca
        self.velocidade = velocidade
        self.inteligencia = inteligencia
        self.resistencia = resistencia

    def __str__(self):
        return (f"Nome: {self.nome}\n"
                f"Força: {self.forca}\n"
                f"Velocidade: {self.velocidade}\n"
                f"Inteligência: {self.inteligencia}\n"
                f"Resistência: {self.resistencia}\n")
