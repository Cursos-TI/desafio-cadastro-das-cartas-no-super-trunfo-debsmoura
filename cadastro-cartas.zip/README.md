# 🃏 Desafio Lógica - Cadastro das Cartas no Super Trunfo

Projeto desenvolvido para a disciplina de Lógica de Programação.  
O objetivo é permitir o **cadastro e listagem de cartas** para o jogo Super Trunfo.

## 🚀 Como rodar o projeto

1. Clone este repositório:
   ```bash
   git clone https://github.com/usuario/cadastro-cartas.git
   ```
2. Acesse a pasta:
   ```bash
   cd cadastro-cartas
   ```
3. Execute o jogo:
   ```bash
   python main.py
   ```

## 📌 Funcionalidades
- Cadastrar cartas com atributos: nome, força, velocidade, inteligência e resistência.
- Listar todas as cartas cadastradas.
- Menu interativo no terminal.

## 📂 Estrutura do projeto
```
cadastro-cartas/
│
├── main.py              # Código principal
├── carta.py             # Classe Carta
├── gerenciador.py       # Funções de cadastro e listagem
├── README.md            # Documentação
└── requirements.txt     # Dependências (opcional)
```

## 🛠 Tecnologias
- Python 3
